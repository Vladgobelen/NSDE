#!/bin/bash

ROOT="/home/diver/sources/RUST/NSDE"
MAIN_DIR="$ROOT/../NSDE_shell"
GH_USER="Vladgobelen"
TIMESTAMP=$(date +%Y%m%d_%H%M)

echo "========================================"
echo " 1. Проверка README.md для nswm"
echo "========================================"
if [ ! -f "$ROOT/nswm/README.md" ]; then
    echo "# nswm" > "$ROOT/nswm/README.md"
    echo "" >> "$ROOT/nswm/README.md"
    echo "Экспериментальная заготовка собственного оконного менеджера (Window Manager) на Rust для среды NSDE." >> "$ROOT/nswm/README.md"
    echo "" >> "$ROOT/nswm/README.md"
    echo "## Текущий статус" >> "$ROOT/nswm/README.md"
    echo "" >> "$ROOT/nswm/README.md"
    echo "Проект находится в стадии разработки. На данный момент реализован только базовый сбор информации об окнах через X11 и Unix-сокет для связи с другими компонентами." >> "$ROOT/nswm/README.md"
    echo "" >> "$ROOT/nswm/README.md"
    echo "## Сборка и запуск" >> "$ROOT/nswm/README.md"
    echo "" >> "$ROOT/nswm/README.md"
    echo '```bash' >> "$ROOT/nswm/README.md"
    echo "cargo build --release" >> "$ROOT/nswm/README.md"
    echo "./target/release/nswm" >> "$ROOT/nswm/README.md"
    echo '```' >> "$ROOT/nswm/README.md"
    echo "Создан README.md для nswm."
fi

echo "========================================"
echo " 2. Заливка подпроектов"
echo "========================================"

# Обработка nspanel (чиним, если git сломан)
echo "--- nspanel ---"
cd "$ROOT/nspanel" || exit 1
if [ ! -e ".git" ] || [ ! -d "$(git rev-parse --git-dir 2>/dev/null)" ]; then
    echo "Починка git для nspanel..."
    rm -rf .git
    git init
    git remote add origin "git@github.com:$GH_USER/nspanel.git"
    git fetch origin main
    git reset --mixed origin/main
    git branch -M main
fi
git add -A
if ! git diff --cached --quiet; then
    git commit -m "nspanel: XDND drag-and-drop files from taskbar"
    git push -f origin main
fi

# Остальные проекты
for proj in "ns-widgets-lua" "nsbridge" "nswm"; do
    echo "--- $proj ---"
    cd "$ROOT/$proj" || continue
    git add -A
    if ! git diff --cached --quiet; then
        git commit -m "Update $proj: features and fixes"
        git push origin main
    fi
done

echo "========================================"
echo " 3. Бэкап и обновление NSDE_shell"
echo "========================================"

if [ ! -d "$MAIN_DIR" ]; then
    echo "Ошибка: Папка $MAIN_DIR не найдена."
    exit 1
fi

cd "$MAIN_DIR"

# Копируем главный README
[ -f "$ROOT/README.md" ] && cp "$ROOT/README.md" "$MAIN_DIR/README.md"

# Делаем бэкап всего проекта NSDE (без папки target, чтобы не раздувать архив)
echo "Создание бэкапа nsde_backup_$TIMESTAMP.tar.gz..."
tar --exclude='target' --exclude='.git' -czf "nsde_backup_$TIMESTAMP.tar.gz" -C "$ROOT/.." NSDE

# Обновляем ссылки на субмодули и пушим
git submodule update --init --remote
git add -A
if ! git diff --cached --quiet; then
    git commit -m "submodules: update all, add backup $TIMESTAMP"
    git push origin main
    echo "Главный репозиторий успешно обновлен и запушен."
else
    echo "В главном репозитории нет изменений."
fi

echo "========================================"
echo " Готово! https://github.com/$GH_USER/NSDE"
echo "========================================"