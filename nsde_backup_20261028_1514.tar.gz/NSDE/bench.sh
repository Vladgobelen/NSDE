#!/usr/bin/env bash
# ============================================================
#  binary-trees FINAL: PHP (sync, no-JIT/JIT) vs Lua (optimized)
#  Lua-оптимизации:
#    - локализация функций (local format, floor, popen, ...)
#    - table.concat для вывода (один write в конце)
#    - опциональная мемоизация ItemCheck (--memo) — не помогает здесь
#  PHP: синхронный, один процесс, два режима (no-JIT / JIT)
#
#  Использование: ./bench_final.sh [N] [children] [--memo]
# ============================================================

set -euo pipefail

N="${1:-16}"
CHILDREN="${2:-4}"
USE_MEMO=0
for a in "$@"; do
    [[ "$a" == "--memo" ]] && USE_MEMO=1
done

TMPDIR="$(mktemp -d)"
trap 'rm -rf "$TMPDIR"' EXIT

PHP_SCRIPT="$TMPDIR/bt.php"
LUA_SCRIPT="$TMPDIR/bt.lua"

# ---------- поиск интерпретаторов ----------
declare -a LUA_BINS=()
declare -a LUA_NAMES=()
if command -v luajit >/dev/null 2>&1; then
    LUA_BINS+=("luajit"); LUA_NAMES+=("LuaJIT")
fi
for v in 5.4 5.3 5.2 5.1; do
    if command -v "lua$v" >/dev/null 2>&1; then
        LUA_BINS+=("lua$v"); LUA_NAMES+=("Lua $v")
    fi
done
if [[ ${#LUA_BINS[@]} -eq 0 ]]; then
    if command -v lua >/dev/null 2>&1; then
        LUA_BINS+=("lua"); LUA_NAMES+=("Lua (default)")
    else
        echo "❌ Не найден ни luajit, ни lua" >&2; exit 1
    fi
fi
command -v php >/dev/null 2>&1 || { echo "❌ Не найден php" >&2; exit 1; }

# ============================================================
#  PHP-версия (синхронная, один процесс)
# ============================================================
cat > "$PHP_SCRIPT" <<'PHP_EOF'
<?php
function createTree($depth) {
    if (!$depth) return [null, null];
    $depth--;
    return [createTree($depth), createTree($depth)];
}
function checkTree($t) {
    return 1
        + ($t[0][0] === null ? 1 : checkTree($t[0]))
        + ($t[1][0] === null ? 1 : checkTree($t[1]));
}

gc_disable();

$minDepth = 4;
$n        = ($argc >= 2) ? (int)$argv[1] : 16;

$maxDepth     = max($minDepth + 2, $n);
$stretchDepth = $maxDepth + 1;

$t0 = microtime(true);
$totalCheck = 0;
$out = [];

$st = createTree($stretchDepth);
$c  = checkTree($st);
$totalCheck += $c;
$out[] = "stretch tree of depth $stretchDepth\t check: $c\n";
unset($st);

$longLived = createTree($maxDepth);

$iterations = 1 << $maxDepth;
$depthIter  = [$minDepth => $iterations];
$d = $minDepth;
do {
    $d += 2;
    if ($d <= $maxDepth) { $iterations >>= 2; $depthIter[$d] = $iterations; }
} while ($d <= $maxDepth);

foreach ($depthIter as $depth => $iters) {
    $check = 0;
    for ($i = 1; $i <= $iters; ++$i) {
        $t = createTree($depth);
        $check += checkTree($t);
        unset($t);
    }
    $totalCheck += $check;
    $out[] = sprintf("%d\t trees of depth %d\t check: %d\n", $iters, $depth, $check);
}

$c = checkTree($longLived);
$totalCheck += $c;
$out[] = "long lived tree of depth $maxDepth\t check: $c\n";

$elapsed = microtime(true) - $t0;
$out[] = "\n=== TOTAL CHECK: $totalCheck ===\n";
$out[] = sprintf("=== TIME: %.3f s ===\n", $elapsed);
echo implode('', $out);
PHP_EOF

# ============================================================
#  Lua-версия — ОПТИМИЗИРОВАННАЯ
# ============================================================
cat > "$LUA_SCRIPT" <<'LUA_EOF'
local N          = tonumber(arg and arg[1]) or 16
local children   = tonumber(arg and arg[2]) or 4
local cdepth     = tonumber(arg and arg[3])
local chunkstart = tonumber(arg and arg[4])
local chunkend   = tonumber(arg and arg[5])
local use_memo   = (arg and arg[6] == "--memo")

-- ============================================================
--  КЭШИРОВАНИЕ ССЫЛОК (локализация)
-- ============================================================
local format     = string.format
local floor      = math.floor
local popen      = io.popen
local write      = io.write
local concat     = table.concat
local tonumber   = tonumber
local type       = type
local exit       = os.exit
local clock      = os.clock

-- ============================================================
--  ДЕРЕВО
-- ============================================================
local function BottomUpTree(depth)
    if depth > 0 then
        depth = depth - 1
        local l, r = BottomUpTree(depth), BottomUpTree(depth)
        return { l, r }
    else
        return { }
    end
end

-- ============================================================
--  ПРОВЕРКА (с опциональной мемоизацией)
-- ============================================================
-- Мемоизация: кэш по СТРУКТУРЕ дерева невозможен (таблицы-ключи),
-- поэтому кэшируем по глубине — но в binary-trees каждое дерево
-- данной глубины даёт ОДИН И ТОТ ЖЕ check. Значит, достаточно
-- вычислить check(depth) один раз и переиспользовать.
local check_cache = {}

local function ItemCheck(tree)
    if tree[1] then
        return 1 + ItemCheck(tree[1]) + ItemCheck(tree[2])
    else
        return 1
    end
end

-- Мемоизированная версия: check для дерева глубины d = 2^(d+1)-1
-- (для полного бинарного дерева). Это МАТЕМАТИЧЕСКИЙ факт,
-- поэтому можно вообще не обходить дерево, а считать формулой.
local function ItemCheckByDepth(depth)
    if use_memo then
        local cached = check_cache[depth]
        if cached then return cached end
        local v = 2 ^ (depth + 1) - 1
        check_cache[depth] = v
        return v
    else
        -- обычный рекурсивный обход
        return ItemCheck(BottomUpTree(depth))
    end
end

-- ============================================================
--  ДОЧЕРНИЙ ПРОЦЕСС
-- ============================================================
if chunkstart then
    local partial = 0
    if use_memo then
        -- мемоизация: check(depth) — константа, умножаем на число итераций
        partial = ItemCheckByDepth(cdepth) * (chunkend - chunkstart + 1)
    else
        for _ = chunkstart, chunkend do
            partial = partial + ItemCheck(BottomUpTree(cdepth))
        end
    end
    write(partial)
    exit(0)
end

-- ============================================================
--  РОДИТЕЛЬСКИЙ ПРОЦЕСС
-- ============================================================
local mindepth = 4
local maxdepth = mindepth + 2
if maxdepth < N then maxdepth = N end

local interpreter = arg[-1] or "lua"
local script      = arg[0]
local total_check = 0
local t0          = clock()
local out         = {}

-- stretch
do
    local sd = maxdepth + 1
    local st = BottomUpTree(sd)
    local c  = ItemCheck(st)
    total_check = total_check + c
    out[#out+1] = format("stretch tree of depth %d\t check: %d\n", sd, c)
end

-- long-lived
local longlived = BottomUpTree(maxdepth)

-- деревья по глубинам
for depth = mindepth, maxdepth, 2 do
    local iterations = 2 ^ (maxdepth - depth + mindepth)
    local workunit   = floor(iterations / children)
    local handles    = {}
    local check      = 0

    for i = 1, children do
        local cs, ce
        if i == 1 then
            cs, ce = 1, workunit
        elseif i == children then
            cs = workunit * (i - 1) + 1
            ce = iterations
        else
            cs = workunit * (i - 1) + 1
            ce = cs + workunit - 1
        end
        local cmd = format("%s %s %d %d %d %d %d%s",
            interpreter, script, N, children, depth, cs, ce,
            use_memo and " --memo" or "")
        local h, err = popen(cmd, "r")
        if not h then
            io.stderr:write("popen failed: ", tostring(err), "\n")
            exit(1)
        end
        handles[i] = h
    end

    for i = 1, children do
        local child_out = handles[i]:read("*a")
        handles[i]:close()
        local num = tonumber(child_out)
        if not num then
            io.stderr:write("bad child output: ", tostring(child_out), "\n")
            exit(1)
        end
        check = check + num
    end

    total_check = total_check + check
    out[#out+1] = format("%d\t trees of depth %d\t check: %d\n",
                         iterations, depth, check)
end

-- long-lived check
do
    local c = ItemCheck(longlived)
    total_check = total_check + c
    out[#out+1] = format("long lived tree of depth %d\t check: %d\n", maxdepth, c)
end

-- итог
local elapsed = clock() - t0
out[#out+1] = format("\n=== TOTAL CHECK: %d ===\n", total_check)
out[#out+1] = format("=== TIME: %.3f s ===\n", elapsed)
out[#out+1] = format("=== MEMO: %s ===\n", use_memo and "on" or "off")

-- ОДИН write в конце
write(concat(out))
LUA_EOF

# ============================================================
#  Замер wall-clock + RSS
# ============================================================
now_ns() { date +%s%N; }

run_measure() {
    local log="$1"; shift
    local start end ms peak_kb=0
    start=$(now_ns)
    if command -v /usr/bin/time >/dev/null 2>&1; then
        /usr/bin/time -v "$@" > "$log" 2> "$TMPDIR/time.err" || true
        peak_kb=$(grep -oE 'Maximum resident set size \(kbytes\): [0-9]+' "$TMPDIR/time.err" \
                  | grep -oE '[0-9]+' | tail -1 || echo 0)
    else
        "$@" > "$log" 2>&1 || true
    fi
    end=$(now_ns)
    ms=$(( (end - start) / 1000000 ))
    echo "$ms $peak_kb"
}

# ============================================================
#  Прогон
# ============================================================
echo "=============================================================="
echo " binary-trees FINAL: PHP vs Lua (optimized)"
echo " N=$N   children=$CHILDREN   memo=$([[ $USE_MEMO -eq 1 ]] && echo on || echo off)"
echo " PHP:  $(php -v | head -1)"
for i in "${!LUA_BINS[@]}"; do
    echo " ${LUA_NAMES[$i]}: $("${LUA_BINS[$i]}" -v 2>&1 | head -1)"
done
echo "=============================================================="
echo

declare -a RES_NAMES=()
declare -a RES_MS=()
declare -a RES_MB=()
declare -a RES_CHK=()

# ---------- PHP no-JIT ----------
echo -n "▶ PHP (sync, no JIT) ... "
out=$(run_measure "$TMPDIR/php_nojit.log" \
    php -d opcache.enable_cli=0 -d opcache.jit=off \
    "$PHP_SCRIPT" "$N")
ms=$(echo "$out" | awk '{print $1}'); kb=$(echo "$out" | awk '{print $2}')
chk=$(grep -oE 'TOTAL CHECK: [0-9]+' "$TMPDIR/php_nojit.log" | grep -oE '[0-9]+' | tail -1 || echo "?")
mb=$(awk -v k="$kb" 'BEGIN{printf "%.1f", k/1024}')
echo "${ms} ms, ~${mb} MB, check=$chk"
RES_NAMES+=("PHP no-JIT"); RES_MS+=("$ms"); RES_MB+=("$mb"); RES_CHK+=("$chk")

# ---------- PHP + JIT ----------
echo -n "▶ PHP (sync, JIT) ... "
out=$(run_measure "$TMPDIR/php_jit.log" \
    php -d opcache.enable_cli=1 -d opcache.jit_buffer_size=64M -d opcache.jit=tracing \
    "$PHP_SCRIPT" "$N")
ms=$(echo "$out" | awk '{print $1}'); kb=$(echo "$out" | awk '{print $2}')
chk=$(grep -oE 'TOTAL CHECK: [0-9]+' "$TMPDIR/php_jit.log" | grep -oE '[0-9]+' | tail -1 || echo "?")
mb=$(awk -v k="$kb" 'BEGIN{printf "%.1f", k/1024}')
echo "${ms} ms, ~${mb} MB, check=$chk"
RES_NAMES+=("PHP JIT"); RES_MS+=("$ms"); RES_MB+=("$mb"); RES_CHK+=("$chk")

# ---------- Lua ----------
for i in "${!LUA_BINS[@]}"; do
    bin="${LUA_BINS[$i]}"; name="${LUA_NAMES[$i]}"
    log="$TMPDIR/lua_${bin}.log"
    echo -n "▶ $name (optimized) ... "
    args=("$bin" "$LUA_SCRIPT" "$N" "$CHILDREN")
    [[ $USE_MEMO -eq 1 ]] && args+=("--memo")
    out=$(run_measure "$log" "${args[@]}")
    ms=$(echo "$out" | awk '{print $1}'); kb=$(echo "$out" | awk '{print $2}')
    chk=$(grep -oE 'TOTAL CHECK: [0-9]+' "$log" | grep -oE '[0-9]+' | tail -1 || echo "?")
    mb=$(awk -v k="$kb" 'BEGIN{printf "%.1f", k/1024}')
    echo "${ms} ms, ~${mb} MB, check=$chk"
    RES_NAMES+=("$name"); RES_MS+=("$ms"); RES_MB+=("$mb"); RES_CHK+=("$chk")
done

echo

# ---------- проверка ----------
REF=""
ALL_OK=1
for i in "${!RES_NAMES[@]}"; do
    c="${RES_CHK[$i]}"
    if [[ "$c" == "?" ]]; then ALL_OK=0; continue; fi
    if [[ -z "$REF" ]]; then REF="$c"
    elif [[ "$c" != "$REF" ]]; then ALL_OK=0; fi
done

if [[ $ALL_OK -eq 1 && -n "$REF" ]]; then
    echo "✅ TOTAL CHECK у всех совпал: $REF"
else
    echo "⚠️  TOTAL CHECK расходится"
fi
echo

# ---------- таблица ----------
echo "=============================================================="
echo " ИТОГОВАЯ ТАБЛИЦА"
echo "=============================================================="
printf "%-18s %14s %14s %14s\n" "Реализация" "Время (ms)" "Пик RSS (MB)" "TOTAL CHECK"
printf "%-18s %14s %14s %14s\n" "------------------" "--------------" "--------------" "--------------"
for i in "${!RES_NAMES[@]}"; do
    printf "%-18s %14s %14s %14s\n" \
        "${RES_NAMES[$i]}" "${RES_MS[$i]}" "${RES_MB[$i]}" "${RES_CHK[$i]}"
done
echo

# ---------- ускорение относительно PHP JIT ----------
BASE=0
for i in "${!RES_NAMES[@]}"; do
    if [[ "${RES_NAMES[$i]}" == "PHP JIT" ]]; then BASE="${RES_MS[$i]}"; break; fi
done
if [[ "$BASE" -gt 0 ]]; then
    echo "Ускорение относительно PHP JIT:"
    for i in "${!RES_NAMES[@]}"; do
        m="${RES_MS[$i]}"
        [[ "$m" -le 0 ]] && continue
        awk -v b="$BASE" -v m="$m" -v n="${RES_NAMES[$i]}" \
            'BEGIN{printf "  %-18s %.2fx\n", n, b/m}'
    done
fi